<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'qiao', 'chou', 'bei', 'xuan', 'wei', 'ge', 'qian', 'wei', 'yu', 'yu', 'bi', 'xuan', 'huan', 'min', 'bi', 'yi',
  0x10 => 'mian', 'yong', 'kai', 'dang', 'yin', 'e', 'chen', 'mao', 'qia', 'ke', 'yu', 'ai', 'qie', 'yan', 'nuo', 'gan',
  0x20 => 'yun', 'zong', 'sai', 'leng', 'fen', 'ying', 'kui', 'kui', 'que', 'gong', 'yun', 'su', 'su', 'qi', 'yao', 'song',
  0x30 => 'huang', 'ji', 'gu', 'ju', 'chuang', 'ni', 'xie', 'kai', 'zheng', 'yong', 'cao', 'xun', 'shen', 'bo', 'kai', 'yuan',
  0x40 => 'xi', 'hun', 'yong', 'yang', 'li', 'sao', 'tao', 'yin', 'ci', 'xu', 'qian', 'tai', 'huang', 'yun', 'shen', 'ming',
  0x50 => 'gong', 'she', 'cong', 'piao', 'mu', 'mu', 'guo', 'chi', 'can', 'can', 'can', 'cui', 'min', 'te', 'zhang', 'tong',
  0x60 => 'ao', 'shuang', 'man', 'guan', 'que', 'zao', 'jiu', 'hui', 'kai', 'lian', 'ou', 'song', 'qin', 'yin', 'lu', 'shang',
  0x70 => 'wei', 'tuan', 'man', 'qian', 'she', 'yong', 'qing', 'kang', 'di', 'zhi', 'lou', 'juan', 'qi', 'qi', 'yu', 'ping',
  0x80 => 'liao', 'cong', 'you', 'chong', 'zhi', 'tong', 'cheng', 'qi', 'qu', 'peng', 'bei', 'bie', 'qiong', 'jiao', 'zeng', 'chi',
  0x90 => 'lian', 'ping', 'kui', 'hui', 'qiao', 'cheng', 'yin', 'yin', 'xi', 'xi', 'dan', 'tan', 'duo', 'dui', 'dui', 'su',
  0xA0 => 'jue', 'ce', 'xiao', 'fan', 'fen', 'lao', 'lao', 'chong', 'han', 'qi', 'xian', 'min', 'jing', 'liao', 'wu', 'can',
  0xB0 => 'jue', 'cu', 'xian', 'tan', 'sheng', 'pi', 'yi', 'chu', 'xian', 'nao', 'dan', 'tan', 'jing', 'song', 'han', 'jiao',
  0xC0 => 'wei', 'xuan', 'dong', 'qin', 'qin', 'ju', 'cao', 'ken', 'xie', 'ying', 'ao', 'mao', 'yi', 'lin', 'se', 'jun',
  0xD0 => 'huai', 'men', 'lan', 'ai', 'lin', 'yan', 'kuo', 'xia', 'chi', 'yu', 'yin', 'dai', 'meng', 'ai', 'meng', 'dui',
  0xE0 => 'qi', 'mo', 'lan', 'men', 'chou', 'zhi', 'nuo', 'nuo', 'yan', 'yang', 'bo', 'zhi', 'kuang', 'kuang', 'you', 'fu',
  0xF0 => 'liu', 'mie', 'cheng', 'hui', 'chan', 'meng', 'lan', 'huai', 'xuan', 'rang', 'chan', 'ji', 'ju', 'huan', 'she', 'yi',
];
